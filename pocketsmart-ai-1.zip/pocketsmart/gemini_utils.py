"""Prompting, Gemini calls, JSON parsing, shopping links and fallback plans."""
import json, os, urllib.parse
from io import BytesIO
from dotenv import load_dotenv
from PIL import Image

load_dotenv()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
_client = None

def client():
    global _client
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        return None
    if _client is None:
        from google import genai
        _client = genai.Client(api_key=key)
    return _client

SCHEMA = ('Return ONLY JSON: {"summary":"","outfit_analysis":"","sections":[{"category":"","allocation":0,'
          '"items":[{"name":"","description":"","estimated_price":0,"quantity":1,"search_terms":""}]}],"tips":[""]}. '
          'estimated_price is PER UNIT in INR. Sum of price*quantity over all items must not exceed the total budget. '
          'Use Indian brands, stores and realistic prices. Leave outfit_analysis empty if no image.')

LINKS = {
    "amazon": "https://www.amazon.in/s?k={q}", "flipkart": "https://www.flipkart.com/search?q={q}",
    "ikea": "https://www.ikea.com/in/en/search/?q={q}", "pepperfry": "https://www.pepperfry.com/site_product/search?q={q}",
    "swiggy": "https://www.swiggy.com/search?query={q}", "zomato": "https://www.zomato.com/search?q={q}",
    "meesho": "https://www.meesho.com/search?q={q}", "bookmyshow": "https://in.bookmyshow.com/search?q={q}",
    "oyo": "https://www.oyorooms.com/search/?location={q}", "makemytrip": "https://www.makemytrip.com/hotels/hotel-listing/?searchText={q}",
    "google": "https://www.google.com/maps/search/{q}", "bluestone": "https://www.bluestone.com/search.html?query={q}",
    "tanishq": "https://www.tanishq.co.in/search?q={q}", "caratlane": "https://www.caratlane.com/search?q={q}",
}
DEFAULT = {"home": ["amazon", "flipkart", "ikea", "pepperfry"], "party": ["amazon", "flipkart", "meesho"],
           "jewelry": ["amazon", "flipkart", "bluestone", "tanishq", "caratlane"]}
PARTY_WORDS = {"cater": ["swiggy", "zomato"], "food": ["swiggy", "zomato"], "venue": ["oyo", "makemytrip", "google"],
               "entertain": ["bookmyshow", "amazon"]}
FALLBACK = {"home": {"Lighting": .25, "Ceiling fans": .25, "Furniture": .3, "Dining": .2},
            "party": {"Venue": .2, "Catering": .4, "Decoration": .2, "Entertainment": .2},
            "jewelry": {"Necklace": .4, "Earrings": .3, "Ring": .3}}

def num(x, d=0.0):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d

def build_prompt(kind, d):
    head = f"You are a budget planning assistant for the Indian market. Total budget: INR {d['total_budget']:,.0f}.\n"
    if kind == "home":
        body = (f"Plan home interiors. Rooms: {', '.join(d['rooms']) or 'any'}. Need {d['num_lights']} lights, {d['num_fans']} ceiling fans, "
                f"{d['num_furniture']} furniture pieces, {d['num_dining_tables']} dining tables. Use sections: lighting, ceiling fans, furniture, dining.")
    elif kind == "party":
        body = (f"Plan a {d['party_type']} party for {d['num_guests']} guests at a {d['venue_type']} venue. Needs: {', '.join(d['needs']) or 'none'}. "
                "Allocate the budget across venue, catering, decoration, entertainment (only the needed ones) plus a small contingency.")
    else:
        body = f"Recommend jewelry for a {d['occasion']}. Style preferences: {d['preferences'] or 'none'}. If an outfit image is attached, match its colours and style."
    return f"{head}{body}\nExtra notes: {d.get('notes') or 'none'}\n{SCHEMA}"

def links_for(kind, cat, q):
    names = DEFAULT[kind]
    if kind == "party":
        for k, v in PARTY_WORDS.items():
            if k in cat.lower():
                names = v
    return [{"name": n.title(), "url": LINKS[n].format(q=urllib.parse.quote_plus(q))} for n in names]

def fallback(kind, budget):
    secs = [{"category": c, "allocation": round(budget * w), "items": [{
        "name": f"Budget {c.lower()} option", "description": "Default suggestion (AI unavailable).",
        "estimated_price": round(budget * w * .9), "quantity": 1, "search_terms": f"{c} {kind} India"}]}
        for c, w in FALLBACK[kind].items()]
    return {"summary": "AI was unavailable, so this is a default allocation.", "sections": secs,
            "tips": ["Compare prices across platforms before buying."]}

def finalize(kind, budget, raw, source):
    secs, spent = [], 0.0
    for s in raw.get("sections") or []:
        cat, items = str(s.get("category", "Other")), []
        for it in s.get("items") or []:
            p, q = num(it.get("estimated_price")), max(int(num(it.get("quantity"), 1)), 1)
            spent += p * q
            name = str(it.get("name", "Item"))
            items.append({"name": name, "description": str(it.get("description", "")), "estimated_price": p, "quantity": q,
                          "links": links_for(kind, cat, it.get("search_terms") or name)})
        secs.append({"category": cat, "allocation": num(s.get("allocation")), "items": items})
    if not secs:
        raise ValueError("empty plan")
    tips = [str(t) for t in raw.get("tips") or []]
    if spent > budget:
        tips.insert(0, "Estimated total is over budget; reduce quantities or pick cheaper options.")
    return {"summary": str(raw.get("summary", "")), "outfit_analysis": str(raw.get("outfit_analysis", "")), "sections": secs,
            "tips": tips, "total_budget": budget, "spent": round(spent, 2), "remaining": round(budget - spent, 2), "source": source}

def generate(kind, data, image_bytes=None):
    budget = float(data["total_budget"])
    try:
        c = client()
        if c is None:
            raise RuntimeError("No Gemini API key configured")
        from google.genai import types
        parts = [build_prompt(kind, data)]
        if image_bytes:
            parts.append(Image.open(BytesIO(image_bytes)))
        resp = c.models.generate_content(model=MODEL, contents=parts, config=types.GenerateContentConfig(
            response_mime_type="application/json", temperature=0.4))
        t = resp.text or ""
        raw = json.loads(t[t.find("{"): t.rfind("}") + 1])
        return finalize(kind, budget, raw, "gemini")
    except Exception as e:  # any AI/parse failure -> safe default plan
        print("Gemini fallback:", repr(e))
        return finalize(kind, budget, fallback(kind, budget), "fallback")
