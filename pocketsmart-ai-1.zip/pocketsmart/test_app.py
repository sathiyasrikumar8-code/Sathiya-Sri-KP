import os, tempfile
os.environ["DB_FILE"] = os.path.join(tempfile.mkdtemp(), "t.json")
os.environ["GEMINI_API_KEY"] = os.environ["GOOGLE_API_KEY"] = ""  # force fallback path: no network needed
from fastapi.testclient import TestClient
import main

c = TestClient(main.app)

def test_full_flow():
    assert c.get("/dashboard", follow_redirects=False).status_code == 303
    r = c.post("/register", data={"username": "sai", "email": "a@b.co", "password": "secret1", "confirm": "secret1"}, follow_redirects=False)
    assert r.status_code == 303
    assert c.get("/dashboard").status_code == 200
    h = c.post("/generate-home", json={"total_budget": 50000, "num_lights": 5, "rooms": ["Kitchen"]}).json()
    assert h["sections"] and h["source"] == "fallback" and h["remaining"] >= 0
    p = c.post("/generate-party", json={"total_budget": 8000, "num_guests": 10, "needs": ["Catering"]}).json()
    assert any(l["name"] == "Swiggy" for s in p["sections"] for i in s["items"] for l in i["links"])
    j = c.post("/generate-jewelry", data={"total_budget": 20000, "occasion": "Wedding"}).json()
    assert j["sections"]
    assert len(c.get("/api/history").json()["history"]) == 3
    assert c.post("/generate-home", json={"total_budget": -5}).status_code == 422
