const inr = n => "₹" + Number(n || 0).toLocaleString("en-IN", {maximumFractionDigits: 0});
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));

function render(r) {
  let h = `<div class="card"><div class="sum"><span>Budget: ${inr(r.total_budget)}</span><span>Planned: ${inr(r.spent)}</span>
    <span class="${r.remaining >= 0 ? "ok" : "bad"}">Remaining: ${inr(r.remaining)}</span></div>
    ${r.summary ? `<p>${esc(r.summary)}</p>` : ""}${r.outfit_analysis ? `<p><b>Outfit:</b> ${esc(r.outfit_analysis)}</p>` : ""}
    ${r.source === "fallback" ? `<p class="muted">Showing default plan (AI unavailable).</p>` : ""}</div>`;
  for (const s of r.sections) {
    h += `<div class="card"><h3>${esc(s.category)} <span class="muted">allocation ${inr(s.allocation)}</span></h3><table>
      <tr><th>Item</th><th>Price</th><th>Qty</th></tr>`;
    for (const i of s.items) {
      h += `<tr><td><b>${esc(i.name)}</b><br><span class="muted">${esc(i.description)}</span><div class="links">` +
        i.links.map(l => `<a href="${esc(l.url)}" target="_blank" rel="noopener noreferrer">${esc(l.name)}</a>`).join("") +
        `</div></td><td>${inr(i.estimated_price)}</td><td>${i.quantity}</td></tr>`;
    }
    h += `</table></div>`;
  }
  if (r.tips.length) h += `<div class="card"><h3>Tips</h3><ul>${r.tips.map(t => `<li>${esc(t)}</li>`).join("")}</ul></div>`;
  return h;
}

const form = document.querySelector("#planner");
if (form) form.addEventListener("submit", async e => {
  e.preventDefault();
  const kind = form.dataset.kind, out = document.querySelector("#result"), btn = form.querySelector("button");
  const fd = new FormData(form);
  let opts;
  if (kind === "jewelry") {
    opts = {method: "POST", body: fd};
  } else {
    const o = {};
    for (const [k, v] of fd.entries()) {
      if (k === "rooms" || k === "needs") (o[k] = o[k] || []).push(v);
      else o[k] = (k.startsWith("total_") || k.startsWith("num_")) && v !== "" ? Number(v) : v;
    }
    opts = {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(o)};
  }
  btn.disabled = true; out.innerHTML = `<p class="muted">Generating your plan…</p>`;
  try {
    const res = await fetch("/generate-" + kind, opts);
    if (res.status === 401) return (location.href = "/login");
    const data = await res.json();
    if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Please check your inputs.");
    out.innerHTML = render(data);
  } catch (err) { out.innerHTML = `<p class="err">${esc(err.message)}</p>`; }
  btn.disabled = false;
});

const hd = document.querySelector("#hdata");
if (hd) JSON.parse(hd.textContent).forEach((h, i) => { document.querySelector("#h" + i).innerHTML = render(h.result); });
