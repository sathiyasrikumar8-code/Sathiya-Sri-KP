import hashlib, hmac, json, os, re, secrets, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
import jwt
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from PIL import Image
from io import BytesIO

load_dotenv()
import gemini_utils as gu

BASE = Path(__file__).parent
SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
EXPIRE = int(os.getenv("TOKEN_MINUTES", "60"))
DB_FILE = Path(os.getenv("DB_FILE", "data.json"))
TITLES = {"home": "Home Interior Budget Planner", "party": "Party Budget Planner", "jewelry": "Jewelry Budget Planner"}

app = FastAPI(title="PocketSmart AI")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
tpl = Jinja2Templates(directory=str(BASE / "templates"))

# ---------- storage & auth helpers ----------
def load():
    return json.loads(DB_FILE.read_text()) if DB_FILE.exists() else {"users": {}, "history": []}

def save(db):
    DB_FILE.write_text(json.dumps(db, indent=2))

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()

def check_pw(pw, stored):
    return hmac.compare_digest(hash_pw(pw, stored.split("$")[0]), stored)

class NotAuth(Exception):
    pass

def current_user(request: Request):
    try:
        u = jwt.decode(request.cookies.get("access_token"), SECRET, algorithms=["HS256"])["sub"]
    except Exception:
        raise NotAuth()
    if u not in load()["users"]:
        raise NotAuth()
    return u

@app.exception_handler(NotAuth)
async def not_auth(request: Request, exc: NotAuth):
    if request.url.path.startswith(("/generate", "/api")):
        return JSONResponse({"detail": "Not authenticated"}, status_code=401)
    return RedirectResponse("/login", status_code=303)

def page(request, name, status=200, **ctx):
    ctx.setdefault("user", None)
    return tpl.TemplateResponse(request, name, ctx, status_code=status)

def login_redirect(username):
    tok = jwt.encode({"sub": username, "exp": datetime.now(timezone.utc) + timedelta(minutes=EXPIRE)}, SECRET, algorithm="HS256")
    r = RedirectResponse("/dashboard", status_code=303)
    r.set_cookie("access_token", tok, httponly=True, samesite="lax", max_age=EXPIRE * 60)
    return r

# ---------- pages & auth ----------
@app.get("/")
def index(request: Request):
    try:
        u = current_user(request)
    except NotAuth:
        u = None
    return page(request, "index.html", user=u)

@app.get("/login")
def login_page(request: Request):
    return page(request, "auth.html", mode="login")

@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    name = username.strip().lower()
    u = load()["users"].get(name)
    if not u or not check_pw(password, u["pw"]):
        return page(request, "auth.html", 401, mode="login", error="Incorrect username or password")
    return login_redirect(name)

@app.get("/register")
def register_page(request: Request):
    return page(request, "auth.html", mode="register")

@app.post("/register")
def register(request: Request, username: str = Form(...), email: str = Form(...),
             password: str = Form(...), confirm: str = Form(...)):
    name, db, err = username.strip().lower(), load(), None
    if not re.fullmatch(r"[a-z0-9_]{3,20}", name):
        err = "Username: 3-20 letters, digits or underscores"
    elif not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        err = "Enter a valid email"
    elif len(password) < 6:
        err = "Password must be at least 6 characters"
    elif password != confirm:
        err = "Passwords do not match"
    elif name in db["users"]:
        err = "Username already taken"
    if err:
        return page(request, "auth.html", 400, mode="register", error=err)
    db["users"][name] = {"email": email, "pw": hash_pw(password)}
    save(db)
    return login_redirect(name)

@app.get("/logout")
def logout():
    r = RedirectResponse("/login", status_code=303)
    r.delete_cookie("access_token")
    return r

def mine(u):
    return [h for h in load()["history"] if h["user"] == u][::-1]

@app.get("/dashboard")
def dashboard(request: Request, u: str = Depends(current_user)):
    return page(request, "dashboard.html", user=u, recent=mine(u)[:3])

@app.get("/planner/{kind}")
def planner(kind: str, request: Request, u: str = Depends(current_user)):
    if kind not in TITLES:
        raise HTTPException(404, "Unknown planner")
    return page(request, "planner.html", user=u, kind=kind, title=TITLES[kind])

@app.get("/history")
def history(request: Request, u: str = Depends(current_user)):
    return page(request, "history.html", user=u, items=mine(u))

@app.get("/api/history")
def api_history(u: str = Depends(current_user)):
    return {"history": mine(u)}

# ---------- AI endpoints ----------
class HomeIn(BaseModel):
    total_budget: float = Field(gt=0, le=1e9)
    num_lights: int = Field(0, ge=0, le=100)
    num_fans: int = Field(0, ge=0, le=100)
    num_furniture: int = Field(0, ge=0, le=100)
    num_dining_tables: int = Field(0, ge=0, le=100)
    rooms: list[str] = []
    notes: str = Field("", max_length=500)

class PartyIn(BaseModel):
    total_budget: float = Field(gt=0, le=1e9)
    num_guests: int = Field(gt=0, le=10000)
    party_type: str = Field("Birthday", max_length=40)
    venue_type: str = Field("Home", max_length=40)
    needs: list[str] = []
    notes: str = Field("", max_length=500)

def run(kind, user, data, image=None):
    result = gu.generate(kind, data, image)
    db = load()
    db["history"].append({"id": uuid.uuid4().hex[:8], "user": user, "kind": kind, "ts": datetime.now(timezone.utc).isoformat(),
                          "inputs": {**data, "has_image": bool(image)}, "result": result})
    save(db)
    return result

@app.post("/generate-home")
def generate_home(body: HomeIn, u: str = Depends(current_user)):
    return run("home", u, body.model_dump())

@app.post("/generate-party")
def generate_party(body: PartyIn, u: str = Depends(current_user)):
    return run("party", u, body.model_dump())

@app.post("/generate-jewelry")
def generate_jewelry(total_budget: float = Form(..., gt=0, le=1e9), occasion: str = Form(..., max_length=40),
                     preferences: str = Form("", max_length=500), image: UploadFile | None = File(None),
                     u: str = Depends(current_user)):
    img = None
    if image is not None and image.filename:
        img = image.file.read(5_000_001)
        try:
            if len(img) > 5_000_000:
                raise ValueError
            Image.open(BytesIO(img)).verify()
        except Exception:
            raise HTTPException(400, "Upload a valid image under 5 MB")
    return run("jewelry", u, {"total_budget": total_budget, "occasion": occasion, "preferences": preferences}, img)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
